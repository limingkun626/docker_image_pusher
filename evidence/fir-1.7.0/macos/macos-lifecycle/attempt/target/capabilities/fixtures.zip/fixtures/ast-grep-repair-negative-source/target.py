print('clean')
